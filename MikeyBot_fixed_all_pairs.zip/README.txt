MIKEY BOT - FIXED VERSION

What was corrected:
1. Removed pandas/numpy/scikit-learn from the Android dependency list.
2. Replaced the RandomForest learning dependency with a lightweight local history adjustment.
3. Replaced hard-coded bcrypt dependency with PBKDF2-HMAC password hashing.
4. Fixed the password storage structure and validation.
5. Removed fake/random market data from the normal analysis path.
6. Added a real EUR/USD candle request through Yahoo Finance's public chart endpoint.
7. If market data cannot be fetched, the app reports the error instead of pretending it has real data.
8. Kept broker execution disabled: the app is signal-only and never submits a real order.
9. Kept Kivy/KivyMD UI so it can be packaged as an Android app.

FIRST LOGIN:
Username: Mikey Bot
Password: mikey0982

Change the password immediately in Security Settings.

NOTE:
The EUR/USD data endpoint is an external service and may change availability.
The signals are technical indicators, not guaranteed predictions.

PAIR SELECTION:
The dashboard now includes multiple major and cross forex pairs.
Tap any pair to select it, then tap ANALYZE SELECTED. The analyzer requests
that pair's recent data and creates the technical signal for that pair.
